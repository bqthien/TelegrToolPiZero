import app

if __name__ == '__main__':
    app.appQuart.run(debug=True)
    #app.appQuart.run(host='0.0.0.0', port=5000)
