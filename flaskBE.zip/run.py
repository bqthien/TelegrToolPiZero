import app

if __name__ == '__main__':
    app.appQuart.run(debug=True)
    #app.appFlask.run(debug=True)
