# from flask_socketio import SocketIO, emit
# from app import appFlask

# socketio = SocketIO(appFlask)

# @socketio.on('connect')
# def handle_connect():
#     print('Hello, the client has been connected')

# def send_notification1(message):
#     SocketIO.emit('notification', {'message': [message]})
