import asyncio
import random
from telethon.sync import TelegramClient, errors
from services.socketService import *
import app
from quart import websocket
import json
import datetime

sessionFolder = 'teleSession/'
minDelay = 3
maxDelay = 6

class Telegr:
    client = None
    id = ''
    hash = ''
    listGroup = ['testnhom20', 'testnhom21']
    listMessage = [['hello from flask', '']]
    messageCount = 0
    isRunning = False

    @classmethod
    def listGroupObj(self):
        return self.listGroup

    @classmethod
    def listMessageObj(self):
        return self.listMessage

    @classmethod
    def clearMessageCount(self):
        self.messageCount = 0

    @classmethod
    def isLoggedIn(self) -> bool:
        #return True
        return self.client is not None and self.client.is_connected()

    ### =====
    @classmethod
    async def login(self, _id, _hash, request_input_phone, request_input_otp) -> bool:
        if Telegr.isLoggedIn():
            return True
        
        self.id = _id
        self.hash = _hash

        try:
            self.client = TelegramClient(f'{sessionFolder}{self.id}', self.id, self.hash) #
            await self.client.start(phone=request_input_phone, code_callback=request_input_otp)
            return True
        except Exception as e:
            return False

    ### =====
    @classmethod
    async def send_message_to_group(self, client: TelegramClient, grpName, msg, mediaPath = '') -> bool:
        # Get the group
        try:
            group_entity = await client.get_input_entity(grpName)
        except Exception as e:
            return str(e)
            
        msg = msg.replace('---', '\n')

        try:
            if mediaPath:
                await client.send_message(group_entity, message=msg, media=mediaPath)
            else:
                await client.send_message(group_entity, message=msg)
        except errors.FloodWaitError as e:
            await asyncio.sleep(e.seconds)
            return f'Flood wait, sleeping for {e.seconds} seconds'
        except Exception as e:
            return str(e)


    # --------------- MAIN APP ---------------
    @classmethod
    async def main(self, stopToken):
        if self.isRunning:
            errorMsg = {'error': 'telegram already running!'}
            await websocket.send(json.dumps(errorMsg))
            return

        if len(self.listMessage) == 0:
            errorMsg = {'error': 'Không có tin nhắn nào!'}
            await websocket.send(json.dumps(errorMsg))
            return

        if not self.listGroup:
            errorMsg = {'error': 'Chưa nhập danh sách group spam!'}
            await websocket.send(json.dumps(errorMsg))
            return

        # Create a Telethon client instance
        if not Telegr.isLoggedIn():
            errorMsg = {'error': 'Cannot login Telegram!'}
            await websocket.send(json.dumps(errorMsg))
            return

        message = self.listMessage[0][0]
        filePath = self.listMessage[0][1]

        me = await self.client.get_me()
        if me is not None:
            accPhone = me.phone
        else:
            accPhone = self.id
        self.isRunning = True

        while True:
            for grpId in self.listGroup:
                grpId = grpId.strip()
                if 't.me' in grpId:
                    grpId = grpId[grpId.rindex('/') + 1:]

                errMsg = await Telegr.send_message_to_group(self.client, grpId, message, filePath)
                timestamp = datetime.datetime.now().strftime("%m-%d %H:%M:%S")
                if not errMsg:
                    self.messageCount += 1
                    msg = {'log': f"{timestamp}  ✔ '{accPhone}' gửi tin nhắn đến '{grpId}' thành công!",
                           'messageCount': f'{self.messageCount}'}
                    await websocket.send(json.dumps(msg))
                else:
                    msg = {'log': f"{timestamp}  ✖ '{accPhone}' gửi tin nhắn đến '{grpId}' thất bại: {errMsg}"}
                    await websocket.send(json.dumps(msg))

                # Delay between message sent
                delay = random.uniform(minDelay, maxDelay)
                await asyncio.sleep(delay)
                if stopToken.isStop:
                    msg = {'info': 'Dừng spam telegram!'}
                    await websocket.send(json.dumps(msg))
                    self.isRunning = False
                    return
