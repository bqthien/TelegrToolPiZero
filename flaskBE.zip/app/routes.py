from quart import Blueprint, render_template, request, redirect
from services.telegrService import Telegr
from ast import literal_eval
from quart import websocket
import json

# Create a Blueprint object
app_routes = Blueprint('app_routes', __name__)

async def request_input_phone() -> str:
    prompt = {'propmt': "Enter your phone number: "}
    websocket.send(json.dumps(prompt))
    phonePrompt = await websocket.receive()
    return phonePrompt
    #return input('Enter your phone:')

async def request_input_otp():
    return input('Enter your OTP: ')

###
@app_routes.route('/')
async def index():
    if Telegr.isLoggedIn():
        return await render_template('index.html',
                                      listGroup=Telegr.listGroupObj(),
                                      listMessage=Telegr.listMessageObj())
    else:
        return await render_template("login.html")

###
@app_routes.route('/addGroup/', methods=['POST'])
async def addGroup():
    newGroup = (await request.form)['content']
    if (newGroup != ""):
        Telegr.listGroup.append(newGroup)
    return redirect('/')

###
@app_routes.route('/addMessage/', methods=['POST'])
async def addMessage():
    newMessage = (await request.form)['content']
    if (newMessage != "" and '---' in newMessage):
        Telegr.listMessage.append(newMessage.split('---'))
    return redirect('/')

###
@app_routes.route('/deleteGroup/<string:name>')
async def deleteGroup(name):
    newList = [grName for grName in Telegr.listGroup if grName != name]
    Telegr.listGroup = newList
    return redirect('/')

###
@app_routes.route('/deleteMessage/<string:delMsg>')
async def deleteMessage(delMsg):
    newList = [msg for msg in Telegr.listMessage if msg != literal_eval(delMsg)]
    Telegr.listMessage = newList
    return redirect('/')

###
@app_routes.route('/home/', methods=['POST'])
async def login_tele():
    creden = await request.form
    id = creden.get("apiId")
    hash = creden.get("apiHash")
    # Login telegram
    await Telegr.login(id, hash, request_input_phone, request_input_otp)
    return redirect('/')
