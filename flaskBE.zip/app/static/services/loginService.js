const btnLogin = document.getElementById("btnLogin");

/*btnLogin.addEventListener('click', () => {
    const id = document.getElementById('apiId').value;
    const hash = document.getElementById('apiHash').value;

    creden = JSON.stringify({ api_id: id, api_hash: hash });
    console.log(creden);

    socket.emit('login', creden);

    /*fetch('/login', {
        method: "POST",
        body: creden,
    }).then(response => response.text())
    .then(data =>{
        console.log(data);
    });
})*/

