const listGrps = document.getElementById("tblGroups");
//const btnAddGrp = document.getElementById("btnAddGroup");
//const btnImport = document.getElementById("btnImport");
const groupInput = document.getElementById("groupInput");

const processLog = document.getElementById("progressUpdate");

const btnRun = document.getElementById("btnRun");
const btnStop = document.getElementById("btnStop");
const lblCount = document.getElementById("lblCount");
const btnClearCount = document.getElementById("btnClearCount");

/// , {'message': "hello from backend"}
btnRun.addEventListener('click', () => {
    console.log('running start function');
    ws.send('start');
});

btnStop.addEventListener('click', () => {
    console.log('running stop function');
    ws.send('stop');
});

btnClearCount.addEventListener('click', () => {
    console.log('clear message count');
    lblCount.innerText = '0';
    ws.send('clearCount');
});

///
/// Listen to update message count event
///
ws.addEventListener('message', function (event) {
    let data = JSON.parse(event.data);
    for (var key in data) {
        switch (key)
        {
            case 'error':
                alert(data[key]);
                break;
            case 'warning':
                alert(data[key]);
                break;
            case 'prompt':
                phone = prompt(data[key]);
                console.log('input prompt: ' + phone);
                ws.send(phone);
                break;
            case 'log':
                let newLog = document.createElement('li');
                newLog.innerText = data[key];
                processLog.prepend(newLog);
                break;
            case 'messageCount':
                lblCount.innerText = data[key];
                break;
            default:
                alert('Unexpected response: ' + data[key]);
                break;
        }
    }
});

///
///
///
/*btnAddGrp.addEventListener('click', () => {
    console.log('running add function');
    let newGroupName = groupInput.value.trim();
    if (newGroupName.length == 0) {
        return;
    }

    // Create a new list item element
    const newGroupItem = document.createElement('li'); 

    newGroupItem.innerHTML =
        `${newGroupName}  <span onclick="editName(this)">✏️</span> <span onclick="deleteName(this)">❌</span>`;

    // Append the new list item to the existing list
    listGrps.appendChild(newGroupItem);
    groupInput.value = "";
});*/


function editName(span) {
    var newName = prompt("Enter a new name", 
        span.parentElement.textContent.trim().slice(2, -2));
        
    if (newName !== null && newName.trim() !== "") {
        span.parentElement.childNodes[1].nodeValue = ` ${newName} `;
    }
}

function deleteName(span) {
    span.parentElement.remove();
}

///
///
///
/*btnImport.addEventListener('click', () => {
    console.log('running import function');
    inputList = groupInput.value.trim();
    if (inputList.length == 0) {
        return;
    }

    gprNames = inputList.split(",");

    gprNames.forEach(name =>
    {
        if (name.trim().length == 0) {
            return;
        }
        // Create a new list item element
        const newGroupItem = document.createElement('li'); 

        newGroupItem.innerHTML =
            `${name}  <span onclick="editName(this)">✏️</span> <span onclick="deleteName(this)">❌</span>`;

        // Append the new list item to the existing list
        listGrps.appendChild(newGroupItem);
    });

    groupInput.value = "";
});*/

///
///
///
/*testPi.addEventListener('click', () => {
    // Get user input (if any)
    inputStr = groupInput.value.trim();
    console.log('input: ' + inputStr);

    cnt = JSON.stringify({ user_input: inputStr });
    console.log(cnt);

    // Send a POST request to the Flask route
    fetch("/process_data", {
        method: "POST",
        // Include user input if needed
        body: cnt,
    })
    .then(response => response.text())
    .then(data => {
        // Handle the response from the Flask function
        console.log(data);
        // Update the page or redirect as needed
    });
})*/