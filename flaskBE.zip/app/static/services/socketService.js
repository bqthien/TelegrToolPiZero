const ws = new WebSocket(`ws://${location.host}/socketio`);

// Connection opened
ws.addEventListener("open", (event) => {
    ws.send("Hello Server, I'm front-end!");
  });
  
/*socket.on('init', function(data) {
    console.log('Received notification:', data.message);
});

socket.on('prompt', function(data) {
    // display the input prompt to the user
    prompt("Prompt: " + data.message);
});*/

function send(event) {
    const message = (new FormData(event.target)).get("message");
    if (message) {
        ws.send(message);
    }
    event.target.reset();
    return false;
}