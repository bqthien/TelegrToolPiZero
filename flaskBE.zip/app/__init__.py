from quart import Quart, websocket
from app.routes import app_routes
from services.telegrService import Telegr
import json
import asyncio
from app.models import stopTelegram

# Create a Quart application instance
appQuart = Quart(__name__)

# Store WebSocket connections
connections = set()
stopToken = stopTelegram()

#####
@appQuart.websocket('/socketio')
async def socketio():
    print('the client has been connected')
    while True:
        mesg = await websocket.receive()
        if mesg == 'start':
            stopToken.isStop = False
            asyncio.ensure_future(Telegr.main(stopToken))
            print('telegram is started!')

        elif mesg == 'stop':
            stopToken.isStop = True
            print(mesg)

        elif mesg == 'clearCount':
            print(mesg)
            Telegr.clearMessageCount()

        else:
            print(f'Invalid message: {mesg}')

# Register the Blueprint with the application
appQuart.register_blueprint(app_routes)