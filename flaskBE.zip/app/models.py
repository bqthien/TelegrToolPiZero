class stopTelegram:
    isStop = False
